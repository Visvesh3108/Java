import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.logging.Level;
import java.util.logging.Logger;

class MyRunnable implements Runnable {

	private final long waitTime;

	public MyRunnable(int timeInMillis)
	{
		this.waitTime = timeInMillis;
	}

	@Override
	public void run()
	{
		try {
			Thread.sleep(waitTime);

			// return current thread name
			System.out.println(Thread
								.currentThread()
								.getName());
		}

		catch (InterruptedException ex) {
			Logger
				.getLogger(MyRunnable.class.getName())
				.log(Level.SEVERE, null, ex);
		}
	}
}

class FutureTaskExample {

	public static void main(String[] args) throws InterruptedException, ExecutionException
	{
		// create two object of MyRunnable class
		// for FutureTask and sleep 1000, 2000
		// millisecond before checking again
		MyRunnable myrunnableobject1 = new MyRunnable(1000);
		MyRunnable myrunnableobject2 = new MyRunnable(2000);
        MyRunnable myrunnableobject3 = new MyRunnable(1500);

		FutureTask<String>
			futureTask1 = new FutureTask<>(myrunnableobject1,
										"FutureTask1 is complete");
		FutureTask<String>
			futureTask2 = new FutureTask<>(myrunnableobject2,
										"FutureTask2 is complete");

        FutureTask<String> futureTask3 = new FutureTask<>(myrunnableobject3,"FutureTask3 is complete");


        
		ExecutorService executor = Executors.newCachedThreadPool();


		executor.submit(futureTask1);

		executor.submit(futureTask2);

        executor.submit(futureTask3);

		List<String> list1 = new ArrayList<>();

        list1.add(futureTask1.get());
        list1.add(futureTask2.get());
        list1.add(futureTask3.get());
        

        executor.shutdown();
        
        System.out.println(list1);
	}
}
