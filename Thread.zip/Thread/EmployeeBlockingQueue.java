import java.util.concurrent.BlockingQueue ;  
import java.util.concurrent.ArrayBlockingQueue ;  
public class EmployeeBlockingQueue{  
    public static void main( String[ ] args ) {  
      // declaring the BlockingQueue of ' bounded ' nature using ArrayBlockingQueue  
      BlockingQueue< String > emps = new ArrayBlockingQueue< >( 5 ) ;  
      try {  
        // Insert element to blocking queue  
        emps.put( "Raj" ) ;  
        emps.put( "Varun" ) ;  
        emps.put( "Nithya" ) ;  
        emps.put( "Hanish" ) ;  
        emps.put( " Einstein" ) ;   
        System.out.println( " Content of BLockingQueue : " + emps ) ;  
    
        
        String temp = emps.take( ) ;   
        System.out.println( " The number removed is : " + temp ) ;  
        
        System.out.println( " Content of BLockingQueue after deleting one element : " + emps ) ;  
      }  
      catch( Exception e ) {  
          e.getStackTrace( ) ;  
      }  
    }  
}  